import hashlib, json, os, pathlib, platform, subprocess, sys
base=pathlib.Path('/tmp/source')
commit='4931c21781413e84ab15ede8dc13cf232639aa4d'
subprocess.run(['git','-c','safe.directory=/git-source','clone','--no-local','--quiet','/git-source',str(base)],check=True)
subprocess.run(['git','checkout','--detach',commit],cwd=base,check=True)
def digest(path): return hashlib.sha256(pathlib.Path(path).read_bytes()).hexdigest()
def output(args): return subprocess.check_output(args,text=True).strip()
metadata={'source':commit,'uid':os.getuid(),'gid':os.getgid(),'kernel':platform.release(),'architecture':platform.machine(),'python':platform.python_version(),'rustc':output(['rustc','--version']),'filesystem':output(['stat','-f','-c','%T',str(base)]),'process_protection':[line for line in pathlib.Path('/proc/self/status').read_text().splitlines() if line.startswith(('CapEff:','NoNewPrivs:','Seccomp:'))],'binary_sha256':{name:digest('/bundle/'+name) for name in ('agentfw','lib-test','native-test')},'runs':[]}
commands=[('lib',['/bundle/lib-test','--nocapture']),('native',['/bundle/native-test','--nocapture']),('stdio',[sys.executable,'scripts/verify-sou54-create-file.py','--run','--repo',str(base),'--agentfw','/bundle/agentfw','--expected-commit',commit,'--native-test-binary','/bundle/lib-test','--output','/tmp/sou54-create-file-final.json']),('races',[sys.executable,'scripts/verify-sou54-create-races.py','--run','--repo',str(base),'--agentfw','/bundle/agentfw','--expected-commit',commit,'--output','/tmp/sou54-create-races-final.json'])]
for name,args in commands:
 with pathlib.Path('/tmp/sou54-'+name+'-final.log').open('wb') as log:
  result=subprocess.run(args,cwd=base,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 metadata['runs'].append({'name':name,'command':args,'exit_code':result.returncode})
 print(name, result.returncode,flush=True)
pathlib.Path('/tmp/sou54-linux-final-environment.json').write_text(json.dumps(metadata,indent=2)+'\n')
sys.exit(0 if all(row['exit_code']==0 for row in metadata['runs']) else 1)
