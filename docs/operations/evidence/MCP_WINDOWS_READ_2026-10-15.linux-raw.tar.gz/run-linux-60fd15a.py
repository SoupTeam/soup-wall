import hashlib,json,os,pathlib,platform,subprocess,sys
base=pathlib.Path('/tmp/sou58-source');commit='60fd15a722672819acb5ec61ad3d955ed59fbd10'
subprocess.run(['git','-c','safe.directory=/git-source','clone','--no-local','--quiet','/git-source',str(base)],check=True)
subprocess.run(['git','checkout','--detach',commit],cwd=base,check=True,stdout=subprocess.DEVNULL)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
files=subprocess.check_output(['git','ls-files','-z'],cwd=base).decode().split('\0')
manifest={rel:{'bytes':(base/rel).stat().st_size,'sha256':sha(base/rel)} for rel in files if rel and (base/rel).is_file()}
pathlib.Path('/out/source-manifest-60fd15a.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
metadata={'source':commit,'binary_build_source':commit,'uid':os.getuid(),'gid':os.getgid(),'kernel':platform.release(),'architecture':platform.machine(),'python':platform.python_version(),'rustc':subprocess.check_output(['rustc','--version'],text=True).strip(),'filesystem':subprocess.check_output(['stat','-f','-c','%T',str(base)],text=True).strip(),'binary_sha256':sha(pathlib.Path('/bundle/agentfw')),'source_manifest_sha256':sha(pathlib.Path('/out/source-manifest-60fd15a.json')),'process_protection':[s for s in pathlib.Path('/proc/self/status').read_text().splitlines() if s.startswith(('CapEff:','NoNewPrivs:','Seccomp:'))],'runs':[]}
for driver,label in [('verify-sou54-create-file.py','create'),('verify-sou56-https-get.py','https')]:
 command=[sys.executable,'-B','scripts/'+driver,'--run','--repo',str(base),'--agentfw','/bundle/agentfw','--expected-commit',commit,'--output','/out/'+label+'-60fd15a.json']
 with pathlib.Path('/out/'+label+'-60fd15a.log').open('wb') as log:
  result=subprocess.run(command,cwd=base,stdout=log,stderr=subprocess.STDOUT,timeout=650)
 metadata['runs'].append({'driver':driver,'command':command,'exit_code':result.returncode})
 print(label,result.returncode,flush=True)
pathlib.Path('/out/linux-environment-60fd15a.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps(metadata));sys.exit(0 if all(r['exit_code']==0 for r in metadata['runs']) else 1)
