import hashlib,json,os,pathlib,platform,subprocess,sys
base=pathlib.Path('/tmp/sou56-source');commit='283108482d792a33c1a07a3eb9e9a94c2484334c'
subprocess.run(['git','-c','safe.directory=/git-source','clone','--no-local','--quiet','/git-source',str(base)],check=True)
subprocess.run(['git','checkout','--detach',commit],cwd=base,check=True,stdout=subprocess.DEVNULL)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
files=subprocess.check_output(['git','ls-files','-z'],cwd=base).decode().split('\0')
manifest={rel:{'bytes':(base/rel).stat().st_size,'sha256':sha(base/rel)} for rel in files if rel and (base/rel).is_file()}
pathlib.Path('/out/source-manifest-2831084.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n')
metadata={'source':commit,'binary_build_source':commit,'uid':os.getuid(),'gid':os.getgid(),'kernel':platform.release(),'architecture':platform.machine(),'python':platform.python_version(),'rustc':subprocess.check_output(['rustc','--version'],text=True).strip(),'openssl':subprocess.check_output(['openssl','version'],text=True).strip(),'filesystem':subprocess.check_output(['stat','-f','-c','%T',str(base)],text=True).strip(),'binary_sha256':sha(pathlib.Path('/bundle/agentfw')),'source_manifest_sha256':sha(pathlib.Path('/out/source-manifest-2831084.json')),'process_protection':[s for s in pathlib.Path('/proc/self/status').read_text().splitlines() if s.startswith(('CapEff:','NoNewPrivs:','Seccomp:'))]}
command=[sys.executable,'-B','scripts/verify-sou56-https-get.py','--run','--repo',str(base),'--agentfw','/bundle/agentfw','--expected-commit',commit,'--output','/out/https-final.json']
with pathlib.Path('/out/https-final.log').open('wb') as log:
 result=subprocess.run(command,cwd=base,stdout=log,stderr=subprocess.STDOUT,timeout=600)
metadata.update(command=command,exit_code=result.returncode)
pathlib.Path('/out/environment-final.json').write_text(json.dumps(metadata,indent=2)+'\n')
print(json.dumps(metadata));sys.exit(result.returncode)
