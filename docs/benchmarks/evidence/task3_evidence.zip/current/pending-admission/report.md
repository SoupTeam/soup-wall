# SOU-17 pending-admission diagnostic

Status: **fail**; complete acceptance: **false**.

Candidate: `e4c9da71019befb46b0f3223c22a7056acea8f02`; stable source/binary: `True`.

| Case | Status | Observation |
| --- | --- | --- |
| benign-before | pass | expected verdict and independent execution/result witnesses matched |
| write-readonly-low | pass | expected verdict and independent execution/result witnesses matched |
| write-readonly-high | pass | expected verdict and independent execution/result witnesses matched |
| delete-high | pass | expected verdict and independent execution/result witnesses matched |
| permissions-high | pass | expected verdict and independent execution/result witnesses matched |
| undeclared-send-high | pass | expected verdict and independent execution/result witnesses matched |
| uncertain-read | pass | expected verdict and independent execution/result witnesses matched |
| read-unknown | technical_unsupported | valid classification did not reach policy |
| read-delete-high | technical_unsupported | valid classification did not reach policy |
| benign-after | pass | expected verdict and independent execution/result witnesses matched |
| pending-classifier-cancellation | fail | original call entered executor after unsupported cancellation was sent before classifier release |

Raw frames, ledgers, classifier/native logs and input hashes are retained beside results.json.
Technical unsupported classifications are not policy successes. Cancellation semantics require agreement.
