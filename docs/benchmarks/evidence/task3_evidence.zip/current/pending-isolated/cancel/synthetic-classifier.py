#!/usr/bin/env python3
# SPDX-License-Identifier: Apache-2.0
import hashlib,json,pathlib,sys,time
root=pathlib.Path('/tmp/sou17-pending-c1elvyvb/classifier')
request=json.loads(sys.stdin.readline())
assert request['tool_name']=='read_document' and request['raw_arguments']=={'name':'inventory'}
replies=json.loads('[{"status": "ok", "actions": ["read"], "unknown": false, "confidence": 0.95, "uncertainty": 0.05, "reason": "Synthetic blocked classifier cancellation"}]')
counter=root/'counter'
index=int(counter.read_text()) if counter.exists() else 0
assert index<len(replies)
counter.write_text(str(index+1))
reply=replies[index]
record={'request':request,'reply':reply,'classifier_sha256':hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest()}
with (root/'inputs.jsonl').open('a') as stream: stream.write(json.dumps(record)+'\n')
if 'cancel'=='cancel':
    (root/'ready.tmp').write_text(json.dumps(record))
    (root/'ready.tmp').replace(root/'ready.json')
    deadline=time.monotonic()+1.8
    while not (root/'release').exists():
        if time.monotonic()>deadline: raise RuntimeError('synthetic release missing')
        time.sleep(.002)
    (root/'emitted').write_text('reply emitted')
print(json.dumps(reply,separators=(',',':')))
