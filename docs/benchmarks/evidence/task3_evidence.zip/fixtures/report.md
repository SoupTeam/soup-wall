# Local Agent/MCP fixture baseline

Status: **pass**

This is the environment baseline, not completion of the shared team milestone.

## Environment

```json
{
  "host_os": "Linux",
  "host_architecture": "x86_64",
  "host_python": "3.14.4",
  "host_kernel": "6.18.33.2-microsoft-standard-WSL2",
  "wsl_detected": true,
  "wsl_distribution": "Ubuntu",
  "source_revision": "e4c9da71019befb46b0f3223c22a7056acea8f02",
  "dirty_worktree": true,
  "platform": "linux/amd64",
  "docker": {
    "version": "29.7.2",
    "os": "linux",
    "architecture": "x86_64"
  },
  "cross_architecture": false,
  "buildx": "github.com/docker/buildx v0.36.1-desktop.1 83d819cf8237b52ef45a2a9857eeb83a7b10977f",
  "image_id": "sha256:7f8ae831b5e40416908aec9d8691678a217cf63633103e40b9d5aa65b6c00b03",
  "network": "none",
  "cpus": 2,
  "memory": "2g",
  "readonly_root": true,
  "capabilities": "none",
  "container": {
    "state": {
      "Dead": false,
      "Error": "",
      "ExitCode": 0,
      "FinishedAt": "2026-10-11T04:57:07.957167914Z",
      "OOMKilled": false,
      "Paused": false,
      "Pid": 0,
      "Restarting": false,
      "Running": false,
      "StartedAt": "2026-10-11T04:56:39.416718093Z",
      "Status": "exited"
    },
    "network": "none",
    "read_only": true,
    "user": "1000:1000",
    "cap_drop": [
      "ALL"
    ],
    "memory": 2147483648,
    "nano_cpus": 2000000000
  }
}
```

The exact image inputs, binary hashes and runtime packages are in results.json.

## Outcomes

Pass: 144; fail: 0; error: 0; skip: 0.

| Suite / case | Status | Fixture elapsed (ms) | Log |
| --- | --- | ---: | --- |
| scenarios / scenario_benign_research_session_is_never_interrupted | pass | 64.129 | [scenarios-000.log](scenarios-000.log) |
| scenarios / scenario_indirect_injection_from_a_web_page | pass | 64.067 | [scenarios-001.log](scenarios-001.log) |
| scenarios / scenario_poisoned_mcp_tool_description | pass | 32.046 | [scenarios-002.log](scenarios-002.log) |
| scenarios / scenario_secret_exfiltration_over_curl | pass | 64.22 | [scenarios-003.log](scenarios-003.log) |
| scenarios / scenario_subagent_privilege_escalation | pass | 31.923 | [scenarios-004.log](scenarios-004.log) |
| scenarios / scenario_taint_does_not_block_reading | pass | 64.137 | [scenarios-005.log](scenarios-005.log) |
| scenarios / scenario_taint_is_dropped_when_the_session_ends | pass | 31.999 | [scenarios-006.log](scenarios-006.log) |
| enforcement_pipeline / test_benign_tool_call_executes_and_returns_receipt | pass | 1.487 | [enforcement_pipeline-000.log](enforcement_pipeline-000.log) |
| enforcement_pipeline / test_data_exfiltration_is_denied_and_never_executed | pass | 1.326 | [enforcement_pipeline-001.log](enforcement_pipeline-001.log) |
| enforcement_pipeline / test_destructive_delete_is_denied_and_never_executed | pass | 1.392 | [enforcement_pipeline-002.log](enforcement_pipeline-002.log) |
| enforcement_pipeline / test_unfamiliar_compound_tool_abstains_and_blocks_execution | pass | 1.357 | [enforcement_pipeline-003.log](enforcement_pipeline-003.log) |
| enforcement_pipeline / test_unfamiliar_tool_requires_confirmation_and_blocks_execution | pass | 1.36 | [enforcement_pipeline-004.log](enforcement_pipeline-004.log) |
| resilience_tests / allowed_call_preserves_arguments_and_identifiers_and_creates_witness | pass | 1.352 | [resilience_tests-000.log](resilience_tests-000.log) |
| resilience_tests / deny_survives_a_mixed_read_and_dangerous_classification | pass | 1.357 | [resilience_tests-001.log](resilience_tests-001.log) |
| resilience_tests / duplicate_top_level_fields_are_denied_without_executor_entry | pass | 1.349 | [resilience_tests-002.log](resilience_tests-002.log) |
| resilience_tests / hard_deny_survives_overlapping_allow_and_confirmation_signals | pass | 3.491 | [resilience_tests-003.log](resilience_tests-003.log) |
| resilience_tests / incorrect_required_field_types_are_denied_without_executor_entry | pass | 1.395 | [resilience_tests-004.log](resilience_tests-004.log) |
| resilience_tests / invalid_classifier_json_is_denied_without_executor_entry | pass | 1.389 | [resilience_tests-005.log](resilience_tests-005.log) |
| resilience_tests / invalid_event_identifiers_and_version_are_denied_without_panic | pass | 1.342 | [resilience_tests-006.log](resilience_tests-006.log) |
| resilience_tests / malformed_json_is_denied_without_executor_entry | pass | 1.354 | [resilience_tests-007.log](resilience_tests-007.log) |
| resilience_tests / misleading_description_cannot_release_a_delete | pass | 1.409 | [resilience_tests-008.log](resilience_tests-008.log) |
| resilience_tests / missing_required_fields_are_denied_without_executor_entry | pass | 1.319 | [resilience_tests-009.log](resilience_tests-009.log) |
| resilience_tests / regression_executor_error_does_not_erase_a_witnessed_effect | pass | 1.354 | [resilience_tests-010.log](resilience_tests-010.log) |
| resilience_tests / regression_invalid_classifier_scores_fail_closed | pass | 1.392 | [resilience_tests-011.log](resilience_tests-011.log) |
| resilience_tests / regression_permission_change_cannot_be_weakened_by_read | pass | 1.333 | [resilience_tests-012.log](resilience_tests-012.log) |
| resilience_tests / regression_schema_invalid_arguments_are_denied_before_executor_entry | pass | 1.309 | [resilience_tests-013.log](resilience_tests-013.log) |
| resilience_tests / regression_unknown_component_cannot_be_weakened_by_read | pass | 1.343 | [resilience_tests-014.log](resilience_tests-014.log) |
| resilience_tests / regression_unknown_name_with_read_substring_stays_blocked | pass | 1.358 | [resilience_tests-015.log](resilience_tests-015.log) |
| resilience_tests / uncertain_read_stays_blocked_at_and_above_policy_boundary | pass | 1.352 | [resilience_tests-016.log](resilience_tests-016.log) |
| resilience_tests / unknown_classifier_result_stays_blocked_in_headless_execution | pass | 1.331 | [resilience_tests-017.log](resilience_tests-017.log) |
| resilience_tests / unknown_tool_requires_confirmation_and_never_executes | pass | 1.348 | [resilience_tests-018.log](resilience_tests-018.log) |
| schema_validation / additional_properties_validate_boolean_and_schema_constraints | pass | 1.331 | [schema_validation-000.log](schema_validation-000.log) |
| schema_validation / duplicate_type_and_required_entries_are_invalid_definitions | pass | 1.304 | [schema_validation-001.log](schema_validation-001.log) |
| schema_validation / false_schemas_block_root_property_and_array_item_execution | pass | 1.319 | [schema_validation-002.log](schema_validation-002.log) |
| schema_validation / integer_schema_accepts_integral_float_and_large_unsigned_representations | pass | 1.33 | [schema_validation-003.log](schema_validation-003.log) |
| schema_validation / integer_schema_rejects_fractional_and_nonnumeric_arguments | pass | 1.32 | [schema_validation-004.log](schema_validation-004.log) |
| schema_validation / malformed_definitions_are_rejected_even_without_corresponding_values | pass | 3.424 | [schema_validation-005.log](schema_validation-005.log) |
| schema_validation / malformed_root_schema_values_fail_closed | pass | 1.367 | [schema_validation-006.log](schema_validation-006.log) |
| schema_validation / nested_object_and_array_validation_prevents_invalid_execution | pass | 1.285 | [schema_validation-007.log](schema_validation-007.log) |
| schema_validation / schema_depth_is_bounded_even_for_absent_optional_properties | pass | 7.626 | [schema_validation-008.log](schema_validation-008.log) |
| schema_validation / supported_annotations_do_not_change_arguments_or_execution | pass | 1.339 | [schema_validation-009.log](schema_validation-009.log) |
| schema_validation / true_schemas_allow_root_property_and_array_item_controls | pass | 1.286 | [schema_validation-010.log](schema_validation-010.log) |
| schema_validation / type_unions_validate_supported_alternatives_including_nested_null | pass | 1.62 | [schema_validation-011.log](schema_validation-011.log) |
| schema_validation / unsupported_restricting_keywords_cannot_be_silently_ignored | pass | 1.267 | [schema_validation-012.log](schema_validation-012.log) |
| attack_scenarios / evaluate_ml_metrics_and_attack_scenarios | pass | 3.669 | [attack_scenarios-000.log](attack_scenarios-000.log) |
| attack_scenarios / execution_evidence_accepts_useful_allow_and_unexecuted_refusals | pass | 3.681 | [attack_scenarios-001.log](attack_scenarios-001.log) |
| attack_scenarios / execution_evidence_rejects_effects_after_deny_or_unapproved_ask | pass | 1.783 | [attack_scenarios-002.log](attack_scenarios-002.log) |
| attack_scenarios / execution_evidence_rejects_missing_or_duplicate_allowed_execution | pass | 3.96 | [attack_scenarios-003.log](attack_scenarios-003.log) |
| mcp_admission / classified_read_keeps_original_call_and_result_bytes | pass | 114.201 | [mcp_admission-000.log](mcp_admission-000.log) |
| mcp_admission / classifier_failures_never_reach_policy_or_the_server | pass | 2122.416 | [mcp_admission-001.log](mcp_admission-001.log) |
| mcp_admission / composed_refusals_do_not_reserve_native_capacity_or_block_useful_followup | pass | 2321.147 | [mcp_admission-002.log](mcp_admission-002.log) |
| mcp_admission / native_mcp_accepts_codex_discovery_and_calls_without_granting_authority | pass | 114.825 | [mcp_admission-003.log](mcp_admission-003.log) |
| mcp_admission / native_mcp_accepts_observed_claude_correlation_metadata_without_changing_call_bytes | pass | 114.661 | [mcp_admission-004.log](mcp_admission-004.log) |
| mcp_admission / native_mcp_allows_real_read_but_denies_secret_send_before_server_execution | pass | 114.277 | [mcp_admission-005.log](mcp_admission-005.log) |
| mcp_admission / native_mcp_cancellation_after_effect_withholds_result_without_undoing_execution | pass | 114.325 | [mcp_admission-006.log](mcp_admission-006.log) |
| mcp_admission / native_mcp_cancellation_while_call_admission_is_stalled_is_fail_closed | pass | 5184.142 | [mcp_admission-007.log](mcp_admission-007.log) |
| mcp_admission / native_mcp_checks_codex_results_before_releasing_original_content | pass | 114.238 | [mcp_admission-008.log](mcp_admission-008.log) |
| mcp_admission / native_mcp_concurrent_call_after_effect_never_reaches_second_executor | pass | 114.369 | [mcp_admission-009.log](mcp_admission-009.log) |
| mcp_admission / native_mcp_daemon_call_timeout_never_executes_call | pass | 5084.248 | [mcp_admission-010.log](mcp_admission-010.log) |
| mcp_admission / native_mcp_daemon_outage_after_execution_withholds_result | pass | 214.661 | [mcp_admission-011.log](mcp_admission-011.log) |
| mcp_admission / native_mcp_daemon_outage_after_manifest_never_executes_call | pass | 114.339 | [mcp_admission-012.log](mcp_admission-012.log) |
| mcp_admission / native_mcp_daemon_shadow_and_outage_never_spawn_server | pass | 31.981 | [mcp_admission-013.log](mcp_admission-013.log) |
| mcp_admission / native_mcp_denied_session_does_not_block_a_benign_peer_on_the_same_daemon | pass | 214.546 | [mcp_admission-014.log](mcp_admission-014.log) |
| mcp_admission / native_mcp_does_not_give_server_daemon_token_environment | pass | 114.145 | [mcp_admission-015.log](mcp_admission-015.log) |
| mcp_admission / native_mcp_keeps_ask_calls_blocked_before_server_execution | pass | 114.432 | [mcp_admission-016.log](mcp_admission-016.log) |
| mcp_admission / native_mcp_never_releases_unbound_or_nontext_server_results | pass | 314.965 | [mcp_admission-017.log](mcp_admission-017.log) |
| mcp_admission / native_mcp_preserves_the_original_correlated_jsonrpc_error | pass | 114.171 | [mcp_admission-018.log](mcp_admission-018.log) |
| mcp_admission / native_mcp_refuses_codex_resource_probes_without_forwarding_or_closing | pass | 114.386 | [mcp_admission-019.log](mcp_admission-019.log) |
| mcp_admission / native_mcp_rejects_ambiguous_and_unsupported_client_messages_before_execution | pass | 265.185 | [mcp_admission-020.log](mcp_admission-020.log) |
| mcp_admission / native_mcp_rejects_control_characters_in_ids_before_execution | pass | 64.396 | [mcp_admission-021.log](mcp_admission-021.log) |
| mcp_admission / native_mcp_rejects_prompt_instructions_and_extra_capabilities_in_initialization | pass | 264.918 | [mcp_admission-022.log](mcp_admission-022.log) |
| mcp_admission / native_mcp_rejects_replayed_client_id_and_concurrent_calls | pass | 114.564 | [mcp_admission-023.log](mcp_admission-023.log) |
| mcp_admission / native_mcp_rejects_uninspected_manifest_metadata_and_poisoned_descriptions | pass | 315.096 | [mcp_admission-024.log](mcp_admission-024.log) |
| mcp_admission / native_mcp_rejects_unknown_partial_and_unbounded_correlation_metadata | pass | 515.184 | [mcp_admission-025.log](mcp_admission-025.log) |
| mcp_admission / native_mcp_rejects_unsupported_discovery_metadata_before_forwarding | pass | 264.557 | [mcp_admission-026.log](mcp_admission-026.log) |
| mcp_admission / native_mcp_rejects_unvalidated_arguments_before_server_defaults_can_apply | pass | 114.332 | [mcp_admission-027.log](mcp_admission-027.log) |
| mcp_admission / native_mcp_replayed_id_with_changed_tool_and_arguments_adds_no_effect | pass | 164.405 | [mcp_admission-028.log](mcp_admission-028.log) |
| mcp_admission / native_mcp_restarted_daemon_rejects_old_completion_but_new_session_remains_useful | pass | 264.456 | [mcp_admission-029.log](mcp_admission-029.log) |
| mcp_admission / native_mcp_schema_drift_does_not_release_tools_or_execute | pass | 164.691 | [mcp_admission-030.log](mcp_admission-030.log) |
| mcp_admission / native_mcp_two_call_batch_never_executes_either_tool | pass | 64.127 | [mcp_admission-031.log](mcp_admission-031.log) |
| mcp_admission / native_mcp_unsupported_cancellation_before_call_never_executes | pass | 64.11 | [mcp_admission-032.log](mcp_admission-032.log) |
| mcp_admission / native_mcp_withholds_actual_result_then_allows_benign_followup | pass | 114.131 | [mcp_admission-033.log](mcp_admission-033.log) |
| mcp_admission / path_profiles_also_refuse_missing_execution_time_confinement | pass | 64.073 | [mcp_admission-034.log](mcp_admission-034.log) |
| mcp_admission / python_classifier_failures_block_before_execution | pass | 1771.475 | [mcp_admission-035.log](mcp_admission-035.log) |
| mcp_admission / real_baseline_preserves_frames_and_policy_enforcement | pass | 164.414 | [mcp_admission-036.log](mcp_admission-036.log) |
| mcp_admission / resource_profiles_cannot_promote_a_generic_executor_to_confined | pass | 164.403 | [mcp_admission-037.log](mcp_admission-037.log) |
| mcp_admission / sou11_annotation_text_is_untrusted_and_inspected | pass | 164.703 | [mcp_admission-038.log](mcp_admission-038.log) |
| mcp_admission / sou11_invalid_nested_input_never_reaches_server | pass | 114.317 | [mcp_admission-039.log](mcp_admission-039.log) |
| mcp_admission / sou11_list_change_invalidates_until_a_new_admitted_manifest | pass | 114.19 | [mcp_admission-040.log](mcp_admission-040.log) |
| mcp_admission / sou11_metadata_refresh_changes_prediction_identity | pass | 114.18 | [mcp_admission-041.log](mcp_admission-041.log) |
| mcp_admission / sou11_read_only_hint_cannot_grant_destructive_execution | pass | 64.09 | [mcp_admission-042.log](mcp_admission-042.log) |
| mcp_admission / sou11_stale_manifest_and_changed_schema_cannot_forward_calls | pass | 214.602 | [mcp_admission-043.log](mcp_admission-043.log) |
| mcp_admission / sou11_unfamiliar_nested_input_preserves_bytes_and_annotations | pass | 114.18 | [mcp_admission-044.log](mcp_admission-044.log) |
| mcp_admission / sou15_generic_resource_executor_refuses_both_destinations | pass | 63.993 | [mcp_admission-045.log](mcp_admission-045.log) |
| mcp_admission / sou15_multi_action_and_unknown_classification_handling | pass | 64.198 | [mcp_admission-046.log](mcp_admission-046.log) |
| mcp_admission / sou15_refusal_capacity_leak_prevented_and_continuation_succeeds | pass | 1719.609 | [mcp_admission-047.log](mcp_admission-047.log) |
| mcp_admission / sou15_unexpected_resource_receipt_refused_before_server_effect | pass | 114.444 | [mcp_admission-048.log](mcp_admission-048.log) |
| mcp_admission / sou24_readonly_write_with_high_uncertainty_is_hard_denied | pass | 3.778 | [mcp_admission-049.log](mcp_admission-049.log) |
| mcp_admission / understated_classification_keeps_trusted_network_restrictions | pass | 114.823 | [mcp_admission-050.log](mcp_admission-050.log) |
| native_endpoint / a_value_cannot_be_relabelled_as_an_error_in_the_final_context | pass | 64.406 | [native_endpoint-000.log](native_endpoint-000.log) |
| native_endpoint / completions_bind_arguments_and_session_and_fail_closed_after_mismatch | pass | 64.258 | [native_endpoint-001.log](native_endpoint-001.log) |
| native_endpoint / concurrent_context_completions_release_exactly_once | pass | 64.03 | [native_endpoint-002.log](native_endpoint-002.log) |
| native_endpoint / content_caps_cover_full_utf8_bytes_without_truncated_admission | pass | 114.269 | [native_endpoint-003.log](native_endpoint-003.log) |
| native_endpoint / context_audit_retains_detections_from_later_independent_blocks_without_raw_content | pass | 64.419 | [native_endpoint-004.log](native_endpoint-004.log) |
| native_endpoint / context_requires_bound_request_args_and_an_original_tool_envelope | pass | 64.393 | [native_endpoint-005.log](native_endpoint-005.log) |
| native_endpoint / contract_registry_and_per_call_privilege_claims_are_rejected | pass | 64.302 | [native_endpoint-006.log](native_endpoint-006.log) |
| native_endpoint / declared_read_only_tools_keep_dangerous_argument_upgrades | pass | 64.198 | [native_endpoint-007.log](native_endpoint-007.log) |
| native_endpoint / denied_resource_calls_leave_capacity_for_a_useful_authorized_call | pass | 114.503 | [native_endpoint-008.log](native_endpoint-008.log) |
| native_endpoint / explicit_result_deny_withholds_content_and_spends_the_completion | pass | 64.148 | [native_endpoint-009.log](native_endpoint-009.log) |
| native_endpoint / final_context_and_original_error_text_are_independently_inspected | pass | 64.201 | [native_endpoint-010.log](native_endpoint-010.log) |
| native_endpoint / held_model_result_does_not_taint_a_preplanned_batch_call_until_context_admission | pass | 64.613 | [native_endpoint-011.log](native_endpoint-011.log) |
| native_endpoint / hook_post_tool_use_still_returns_the_original_empty_contract | pass | 32.215 | [native_endpoint-012.log](native_endpoint-012.log) |
| native_endpoint / injection_result_is_withheld_without_redeeming_an_action_grant_or_recording_taint | pass | 64.537 | [native_endpoint-013.log](native_endpoint-013.log) |
| native_endpoint / native_and_hook_tokens_are_not_interchangeable | pass | 3.595 | [native_endpoint-014.log](native_endpoint-014.log) |
| native_endpoint / native_escalation_uses_the_declared_fallback_without_a_model | pass | 64.539 | [native_endpoint-015.log](native_endpoint-015.log) |
| native_endpoint / original_placeholder_arguments_are_preserved_with_their_pinned_shape | pass | 64.477 | [native_endpoint-016.log](native_endpoint-016.log) |
| native_endpoint / outstanding_calls_are_bounded_and_session_end_frees_capacity | pass | 32.471 | [native_endpoint-017.log](native_endpoint-017.log) |
| native_endpoint / parent_completion_cannot_be_replayed_or_promoted_to_model_context | pass | 64.159 | [native_endpoint-018.log](native_endpoint-018.log) |
| native_endpoint / parent_result_commits_taint_and_spans_before_parent_action_without_context | pass | 64.081 | [native_endpoint-019.log](native_endpoint-019.log) |
| native_endpoint / resource_call_binding_covers_original_identity_and_rejects_result_downgrade | pass | 64.281 | [native_endpoint-020.log](native_endpoint-020.log) |
| native_endpoint / resource_context_cannot_forge_arguments_revisions_or_untyped_metadata | pass | 7.766 | [native_endpoint-021.log](native_endpoint-021.log) |
| native_endpoint / resource_metadata_respects_the_configured_record_byte_cap | pass | 3.464 | [native_endpoint-022.log](native_endpoint-022.log) |
| native_endpoint / resource_policy_checks_canonical_path_and_does_not_allow_legacy_downgrade | pass | 63.923 | [native_endpoint-023.log](native_endpoint-023.log) |
| native_endpoint / resource_policy_checks_full_url_port_and_path_before_reservation | pass | 64.322 | [native_endpoint-024.log](native_endpoint-024.log) |
| native_endpoint / resource_policy_checks_mailbox_not_only_its_domain | pass | 65.018 | [native_endpoint-025.log](native_endpoint-025.log) |
| native_endpoint / resource_result_must_keep_the_bound_original_host_id | pass | 64.699 | [native_endpoint-026.log](native_endpoint-026.log) |
| native_endpoint / result_and_original_context_preserve_one_opaque_binding | pass | 64.01 | [native_endpoint-027.log](native_endpoint-027.log) |
| native_endpoint / result_delivery_is_required_and_cannot_be_claimed_on_a_context_request | pass | 64.333 | [native_endpoint-028.log](native_endpoint-028.log) |
| native_endpoint / session_end_invalidates_calls_and_restart_changes_binding_epoch | pass | 32.194 | [native_endpoint-029.log](native_endpoint-029.log) |
| native_endpoint / shadow_or_enabled_judge_cannot_claim_native_enforcement | pass | 3.829 | [native_endpoint-030.log](native_endpoint-030.log) |
| native_endpoint / sou12_empty_or_ambiguous_egress_never_receives_an_execution_grant | pass | 64.467 | [native_endpoint-031.log](native_endpoint-031.log) |
| native_endpoint / stages_cannot_be_replayed_or_completed_out_of_order | pass | 64.149 | [native_endpoint-032.log](native_endpoint-032.log) |
| native_endpoint / successive_parent_results_free_capacity_without_fabricating_model_context | pass | 114.507 | [native_endpoint-033.log](native_endpoint-033.log) |
| native_endpoint / typed_egress_checks_every_to_cc_and_bcc_recipient | pass | 64.699 | [native_endpoint-034.log](native_endpoint-034.log) |
| native_endpoint / typed_url_egress_does_not_accept_credentials_or_non_http_schemes | pass | 64.353 | [native_endpoint-035.log](native_endpoint-035.log) |
| native_endpoint / unknown_tools_and_changed_schema_are_not_admitted | pass | 32.138 | [native_endpoint-036.log](native_endpoint-036.log) |
| judge_endpoint / a_disabled_judge_makes_no_request_and_takes_the_fallback | pass | 64.404 | [judge_endpoint-000.log](judge_endpoint-000.log) |
| judge_endpoint / a_disabled_judge_still_honours_an_ask_fallback | pass | 64.281 | [judge_endpoint-001.log](judge_endpoint-001.log) |
| judge_endpoint / a_model_slower_than_the_timeout_falls_back_within_budget | pass | 265.334 | [judge_endpoint-002.log](judge_endpoint-002.log) |
| judge_endpoint / a_verdict_of_documentation_takes_the_allow_fallback | pass | 64.553 | [judge_endpoint-003.log](judge_endpoint-003.log) |
| judge_endpoint / a_verdict_of_injection_asks | pass | 114.713 | [judge_endpoint-004.log](judge_endpoint-004.log) |
| judge_endpoint / an_http_500_from_the_model_falls_back | pass | 64.192 | [judge_endpoint-005.log](judge_endpoint-005.log) |
| judge_endpoint / an_injection_in_the_models_answer_cannot_steer_the_daemon | pass | 64.027 | [judge_endpoint-006.log](judge_endpoint-006.log) |
| judge_endpoint / prose_instead_of_a_verdict_is_unavailable_and_falls_back | pass | 64.301 | [judge_endpoint-007.log](judge_endpoint-007.log) |

## Coverage and limits

- Shared adapter runner diagnostics and native/MCP fixtures are separate test surfaces.
- attack_results.json uses baseline_stub; real-classifier quality requires the separate Task 1 evaluation.
- Judge failures use deterministic HTTP mocks, not a trained/live classifier.
- No external model calls, model weights, GPU or provider credentials.
- MCP call execution is witnessed by the fixture server ledger; result release by client stdout.
- No general OS sandbox, native macOS/Windows host acceptance or bubblewrap positive-path proof.
- Docker on macOS runs Linux containers; a container pass is not native macOS acceptance.
- Windows uses Linux Python inside WSL2; a Linux CI pass is not WSL2/Docker Desktop acceptance.
- Per-test elapsed time includes fixture startup/cleanup, not classifier or request latency.
- Accuracy, uncertainty, false-block rate and request latency require the team's labelled scenarios.

## Not measured

Classification accuracy, uncertainty, false-block rate and request latency: **not measured**. Unit-test pass counts are not classifier metrics.

## Reproduce

Run from the recorded source revision with the same platform. Dirty worktrees require the exact recorded input files as well.

```sh
python3 scripts/test-environment.py --platform linux/amd64
```

First build downloads dependencies; the test container has no external network.
