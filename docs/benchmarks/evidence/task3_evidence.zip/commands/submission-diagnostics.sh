#!/bin/bash
# SPDX-License-Identifier: Apache-2.0
set -eu
cd /work
out=/checks
run() {
    name=$1
    expected=$2
    shift 2
    set +e
    "$@" > "$out/$name.log" 2>&1
    code=$?
    set -e
    printf '%s\n' "$code" > "$out/$name.exit"
    printf '%s: exit %s (expected %s)\n' "$name" "$code" "$expected"
    if [ "$code" -ne "$expected" ]; then
        tail -n 50 "$out/$name.log"
        return 1
    fi
}
run baseline-unit 0 python3 -m unittest discover -s rule_baseline -p 'test_*.py' -v
run evaluator-unit 0 python3 -m unittest discover -s eval -p 'test_*.py' -v
run model-unit 0 python3 -m unittest discover -s experiments/local_classifier -p 'test_*.py' -v
run classification 1 python3 eval/eval_runner.py eval/fixtures/soup_task1_evaluation_cases_v0.4.json eval/fixtures/soup_task1_challenge_cases_v0.1.json eval/fixtures/soup_task1_mixed_actions_urtisto_v0.1.json eval/fixtures/soup_task1_benign_comparison_urtisto_v0.1.json --classifier-path rule_baseline --out-dir /checks/classification
run pending-admission 2 python3 scripts/verify-sou17-pending-admission.py --repo /work --agentfw /work/target/debug/agentfw --expected-commit e4c9da71019befb46b0f3223c22a7056acea8f02 --output /checks/pending-admission
