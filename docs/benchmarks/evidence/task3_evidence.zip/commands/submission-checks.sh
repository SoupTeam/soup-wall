#!/bin/bash
# SPDX-License-Identifier: Apache-2.0
set -eu
cd /work
out=/checks
run() {
    name=$1
    shift
    set +e
    "$@" > "$out/$name.log" 2>&1
    code=$?
    set -e
    printf '%s\n' "$code" > "$out/$name.exit"
    printf '%s: %s\n' "$name" "$code"
    if [ "$code" -ne 0 ]; then
        tail -n 50 "$out/$name.log"
        return "$code"
    fi
}
run fmt cargo fmt --all -- --check
run clippy cargo clippy --workspace --all-targets --locked --offline -- -D warnings
run workspace cargo test --workspace --locked --offline
run scripts python3 -m unittest discover -s scripts/tests -p 'test_*.py' -v
run benchmarks python3 -m unittest discover -s scripts/benchmarks -p 'test_*.py' -v
run build cargo build --locked --offline -p agentfw
