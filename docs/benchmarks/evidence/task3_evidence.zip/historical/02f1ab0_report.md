# Local Agent/MCP fixture baseline

Status: **pass**

This is the environment baseline, not completion of the shared team milestone.

## Environment

```json
{
  "host_os": "Linux",
  "host_architecture": "x86_64",
  "host_python": "3.14.4",
  "host_kernel": "6.18.33.2-microsoft-standard-WSL2",
  "wsl_detected": true,
  "wsl_distribution": "Ubuntu",
  "source_revision": "02f1ab05d1cdc7711dfe4efd18a3798c32a5394b",
  "dirty_worktree": false,
  "platform": "linux/amd64",
  "docker": {
    "version": "29.7.2",
    "os": "linux",
    "architecture": "x86_64"
  },
  "cross_architecture": false,
  "buildx": "github.com/docker/buildx v0.36.1-desktop.1 83d819cf8237b52ef45a2a9857eeb83a7b10977f",
  "image_id": "sha256:e6343397af68662fd96ae8cc756c6b74583d6353ef42ba7d274f1eecd985d7d7",
  "network": "none",
  "cpus": 2,
  "memory": "2g",
  "readonly_root": true,
  "capabilities": "none",
  "container": {
    "state": {
      "Dead": false,
      "Error": "",
      "ExitCode": 0,
      "FinishedAt": "2026-10-11T04:11:24.984016128Z",
      "OOMKilled": false,
      "Paused": false,
      "Pid": 0,
      "Restarting": false,
      "Running": false,
      "StartedAt": "2026-10-11T04:10:56.288869485Z",
      "Status": "exited"
    },
    "network": "none",
    "read_only": true,
    "user": "1000:1000",
    "cap_drop": [
      "ALL"
    ],
    "memory": 2147483648,
    "nano_cpus": 2000000000
  }
}
```

The exact image inputs, binary hashes and runtime packages are in results.json.

## Outcomes

Pass: 103; fail: 0; error: 0; skip: 0.

| Suite / case | Status | Fixture elapsed (ms) | Log |
| --- | --- | ---: | --- |
| scenarios / scenario_benign_research_session_is_never_interrupted | pass | 64.24 | [scenarios-000.log](scenarios-000.log) |
| scenarios / scenario_indirect_injection_from_a_web_page | pass | 64.166 | [scenarios-001.log](scenarios-001.log) |
| scenarios / scenario_poisoned_mcp_tool_description | pass | 32.058 | [scenarios-002.log](scenarios-002.log) |
| scenarios / scenario_secret_exfiltration_over_curl | pass | 64.449 | [scenarios-003.log](scenarios-003.log) |
| scenarios / scenario_subagent_privilege_escalation | pass | 31.901 | [scenarios-004.log](scenarios-004.log) |
| scenarios / scenario_taint_does_not_block_reading | pass | 64.131 | [scenarios-005.log](scenarios-005.log) |
| scenarios / scenario_taint_is_dropped_when_the_session_ends | pass | 32.343 | [scenarios-006.log](scenarios-006.log) |
| mcp_admission / classified_read_keeps_original_call_and_result_bytes | pass | 114.282 | [mcp_admission-000.log](mcp_admission-000.log) |
| mcp_admission / classifier_failures_never_reach_policy_or_the_server | pass | 2119.422 | [mcp_admission-001.log](mcp_admission-001.log) |
| mcp_admission / composed_refusals_do_not_reserve_native_capacity_or_block_useful_followup | pass | 2420.253 | [mcp_admission-002.log](mcp_admission-002.log) |
| mcp_admission / native_mcp_accepts_codex_discovery_and_calls_without_granting_authority | pass | 114.338 | [mcp_admission-003.log](mcp_admission-003.log) |
| mcp_admission / native_mcp_accepts_observed_claude_correlation_metadata_without_changing_call_bytes | pass | 114.318 | [mcp_admission-004.log](mcp_admission-004.log) |
| mcp_admission / native_mcp_allows_real_read_but_denies_secret_send_before_server_execution | pass | 114.529 | [mcp_admission-005.log](mcp_admission-005.log) |
| mcp_admission / native_mcp_cancellation_after_effect_withholds_result_without_undoing_execution | pass | 114.342 | [mcp_admission-006.log](mcp_admission-006.log) |
| mcp_admission / native_mcp_cancellation_while_call_admission_is_stalled_is_fail_closed | pass | 5184.511 | [mcp_admission-007.log](mcp_admission-007.log) |
| mcp_admission / native_mcp_checks_codex_results_before_releasing_original_content | pass | 114.807 | [mcp_admission-008.log](mcp_admission-008.log) |
| mcp_admission / native_mcp_concurrent_call_after_effect_never_reaches_second_executor | pass | 115.179 | [mcp_admission-009.log](mcp_admission-009.log) |
| mcp_admission / native_mcp_daemon_call_timeout_never_executes_call | pass | 5137.363 | [mcp_admission-010.log](mcp_admission-010.log) |
| mcp_admission / native_mcp_daemon_outage_after_execution_withholds_result | pass | 214.991 | [mcp_admission-011.log](mcp_admission-011.log) |
| mcp_admission / native_mcp_daemon_outage_after_manifest_never_executes_call | pass | 114.381 | [mcp_admission-012.log](mcp_admission-012.log) |
| mcp_admission / native_mcp_daemon_shadow_and_outage_never_spawn_server | pass | 16.051 | [mcp_admission-013.log](mcp_admission-013.log) |
| mcp_admission / native_mcp_denied_session_does_not_block_a_benign_peer_on_the_same_daemon | pass | 214.496 | [mcp_admission-014.log](mcp_admission-014.log) |
| mcp_admission / native_mcp_does_not_give_server_daemon_token_environment | pass | 114.218 | [mcp_admission-015.log](mcp_admission-015.log) |
| mcp_admission / native_mcp_keeps_ask_calls_blocked_before_server_execution | pass | 114.523 | [mcp_admission-016.log](mcp_admission-016.log) |
| mcp_admission / native_mcp_never_releases_unbound_or_nontext_server_results | pass | 315.419 | [mcp_admission-017.log](mcp_admission-017.log) |
| mcp_admission / native_mcp_preserves_the_original_correlated_jsonrpc_error | pass | 114.992 | [mcp_admission-018.log](mcp_admission-018.log) |
| mcp_admission / native_mcp_refuses_codex_resource_probes_without_forwarding_or_closing | pass | 114.827 | [mcp_admission-019.log](mcp_admission-019.log) |
| mcp_admission / native_mcp_rejects_ambiguous_and_unsupported_client_messages_before_execution | pass | 264.953 | [mcp_admission-020.log](mcp_admission-020.log) |
| mcp_admission / native_mcp_rejects_control_characters_in_ids_before_execution | pass | 64.416 | [mcp_admission-021.log](mcp_admission-021.log) |
| mcp_admission / native_mcp_rejects_prompt_instructions_and_extra_capabilities_in_initialization | pass | 264.826 | [mcp_admission-022.log](mcp_admission-022.log) |
| mcp_admission / native_mcp_rejects_replayed_client_id_and_concurrent_calls | pass | 114.849 | [mcp_admission-023.log](mcp_admission-023.log) |
| mcp_admission / native_mcp_rejects_uninspected_manifest_metadata_and_poisoned_descriptions | pass | 315.698 | [mcp_admission-024.log](mcp_admission-024.log) |
| mcp_admission / native_mcp_rejects_unknown_partial_and_unbounded_correlation_metadata | pass | 565.897 | [mcp_admission-025.log](mcp_admission-025.log) |
| mcp_admission / native_mcp_rejects_unsupported_discovery_metadata_before_forwarding | pass | 264.444 | [mcp_admission-026.log](mcp_admission-026.log) |
| mcp_admission / native_mcp_rejects_unvalidated_arguments_before_server_defaults_can_apply | pass | 114.282 | [mcp_admission-027.log](mcp_admission-027.log) |
| mcp_admission / native_mcp_replayed_id_with_changed_tool_and_arguments_adds_no_effect | pass | 164.29 | [mcp_admission-028.log](mcp_admission-028.log) |
| mcp_admission / native_mcp_restarted_daemon_rejects_old_completion_but_new_session_remains_useful | pass | 264.644 | [mcp_admission-029.log](mcp_admission-029.log) |
| mcp_admission / native_mcp_schema_drift_does_not_release_tools_or_execute | pass | 164.229 | [mcp_admission-030.log](mcp_admission-030.log) |
| mcp_admission / native_mcp_two_call_batch_never_executes_either_tool | pass | 64.039 | [mcp_admission-031.log](mcp_admission-031.log) |
| mcp_admission / native_mcp_unsupported_cancellation_before_call_never_executes | pass | 64.091 | [mcp_admission-032.log](mcp_admission-032.log) |
| mcp_admission / native_mcp_withholds_actual_result_then_allows_benign_followup | pass | 114.404 | [mcp_admission-033.log](mcp_admission-033.log) |
| mcp_admission / path_profiles_also_refuse_missing_execution_time_confinement | pass | 64.302 | [mcp_admission-034.log](mcp_admission-034.log) |
| mcp_admission / python_classifier_failures_block_before_execution | pass | 1771.2 | [mcp_admission-035.log](mcp_admission-035.log) |
| mcp_admission / real_baseline_preserves_frames_and_policy_enforcement | pass | 164.359 | [mcp_admission-036.log](mcp_admission-036.log) |
| mcp_admission / resource_profiles_cannot_promote_a_generic_executor_to_confined | pass | 164.526 | [mcp_admission-037.log](mcp_admission-037.log) |
| mcp_admission / sou11_annotation_text_is_untrusted_and_inspected | pass | 164.398 | [mcp_admission-038.log](mcp_admission-038.log) |
| mcp_admission / sou11_invalid_nested_input_never_reaches_server | pass | 164.395 | [mcp_admission-039.log](mcp_admission-039.log) |
| mcp_admission / sou11_list_change_invalidates_until_a_new_admitted_manifest | pass | 114.773 | [mcp_admission-040.log](mcp_admission-040.log) |
| mcp_admission / sou11_metadata_refresh_changes_prediction_identity | pass | 114.839 | [mcp_admission-041.log](mcp_admission-041.log) |
| mcp_admission / sou11_read_only_hint_cannot_grant_destructive_execution | pass | 64.736 | [mcp_admission-042.log](mcp_admission-042.log) |
| mcp_admission / sou11_stale_manifest_and_changed_schema_cannot_forward_calls | pass | 214.746 | [mcp_admission-043.log](mcp_admission-043.log) |
| mcp_admission / sou11_unfamiliar_nested_input_preserves_bytes_and_annotations | pass | 114.024 | [mcp_admission-044.log](mcp_admission-044.log) |
| mcp_admission / sou15_generic_resource_executor_refuses_both_destinations | pass | 63.963 | [mcp_admission-045.log](mcp_admission-045.log) |
| mcp_admission / sou15_multi_action_and_unknown_classification_handling | pass | 64.569 | [mcp_admission-046.log](mcp_admission-046.log) |
| mcp_admission / sou15_refusal_capacity_leak_prevented_and_continuation_succeeds | pass | 1719.576 | [mcp_admission-047.log](mcp_admission-047.log) |
| mcp_admission / sou15_unexpected_resource_receipt_refused_before_server_effect | pass | 114.167 | [mcp_admission-048.log](mcp_admission-048.log) |
| mcp_admission / sou24_readonly_write_with_high_uncertainty_is_hard_denied | pass | 3.83 | [mcp_admission-049.log](mcp_admission-049.log) |
| mcp_admission / understated_classification_keeps_trusted_network_restrictions | pass | 114.267 | [mcp_admission-050.log](mcp_admission-050.log) |
| native_endpoint / a_value_cannot_be_relabelled_as_an_error_in_the_final_context | pass | 64.485 | [native_endpoint-000.log](native_endpoint-000.log) |
| native_endpoint / completions_bind_arguments_and_session_and_fail_closed_after_mismatch | pass | 64.231 | [native_endpoint-001.log](native_endpoint-001.log) |
| native_endpoint / concurrent_context_completions_release_exactly_once | pass | 64.156 | [native_endpoint-002.log](native_endpoint-002.log) |
| native_endpoint / content_caps_cover_full_utf8_bytes_without_truncated_admission | pass | 114.438 | [native_endpoint-003.log](native_endpoint-003.log) |
| native_endpoint / context_audit_retains_detections_from_later_independent_blocks_without_raw_content | pass | 64.686 | [native_endpoint-004.log](native_endpoint-004.log) |
| native_endpoint / context_requires_bound_request_args_and_an_original_tool_envelope | pass | 64.486 | [native_endpoint-005.log](native_endpoint-005.log) |
| native_endpoint / contract_registry_and_per_call_privilege_claims_are_rejected | pass | 64.178 | [native_endpoint-006.log](native_endpoint-006.log) |
| native_endpoint / declared_read_only_tools_keep_dangerous_argument_upgrades | pass | 64.342 | [native_endpoint-007.log](native_endpoint-007.log) |
| native_endpoint / denied_resource_calls_leave_capacity_for_a_useful_authorized_call | pass | 114.594 | [native_endpoint-008.log](native_endpoint-008.log) |
| native_endpoint / explicit_result_deny_withholds_content_and_spends_the_completion | pass | 64.551 | [native_endpoint-009.log](native_endpoint-009.log) |
| native_endpoint / final_context_and_original_error_text_are_independently_inspected | pass | 64.915 | [native_endpoint-010.log](native_endpoint-010.log) |
| native_endpoint / held_model_result_does_not_taint_a_preplanned_batch_call_until_context_admission | pass | 64.522 | [native_endpoint-011.log](native_endpoint-011.log) |
| native_endpoint / hook_post_tool_use_still_returns_the_original_empty_contract | pass | 32.717 | [native_endpoint-012.log](native_endpoint-012.log) |
| native_endpoint / injection_result_is_withheld_without_redeeming_an_action_grant_or_recording_taint | pass | 64.402 | [native_endpoint-013.log](native_endpoint-013.log) |
| native_endpoint / native_and_hook_tokens_are_not_interchangeable | pass | 3.762 | [native_endpoint-014.log](native_endpoint-014.log) |
| native_endpoint / native_escalation_uses_the_declared_fallback_without_a_model | pass | 64.228 | [native_endpoint-015.log](native_endpoint-015.log) |
| native_endpoint / original_placeholder_arguments_are_preserved_with_their_pinned_shape | pass | 64.418 | [native_endpoint-016.log](native_endpoint-016.log) |
| native_endpoint / outstanding_calls_are_bounded_and_session_end_frees_capacity | pass | 32.096 | [native_endpoint-017.log](native_endpoint-017.log) |
| native_endpoint / parent_completion_cannot_be_replayed_or_promoted_to_model_context | pass | 64.185 | [native_endpoint-018.log](native_endpoint-018.log) |
| native_endpoint / parent_result_commits_taint_and_spans_before_parent_action_without_context | pass | 64.407 | [native_endpoint-019.log](native_endpoint-019.log) |
| native_endpoint / resource_call_binding_covers_original_identity_and_rejects_result_downgrade | pass | 64.356 | [native_endpoint-020.log](native_endpoint-020.log) |
| native_endpoint / resource_context_cannot_forge_arguments_revisions_or_untyped_metadata | pass | 7.735 | [native_endpoint-021.log](native_endpoint-021.log) |
| native_endpoint / resource_metadata_respects_the_configured_record_byte_cap | pass | 3.548 | [native_endpoint-022.log](native_endpoint-022.log) |
| native_endpoint / resource_policy_checks_canonical_path_and_does_not_allow_legacy_downgrade | pass | 64.338 | [native_endpoint-023.log](native_endpoint-023.log) |
| native_endpoint / resource_policy_checks_full_url_port_and_path_before_reservation | pass | 114.715 | [native_endpoint-024.log](native_endpoint-024.log) |
| native_endpoint / resource_policy_checks_mailbox_not_only_its_domain | pass | 64.776 | [native_endpoint-025.log](native_endpoint-025.log) |
| native_endpoint / resource_result_must_keep_the_bound_original_host_id | pass | 64.14 | [native_endpoint-026.log](native_endpoint-026.log) |
| native_endpoint / result_and_original_context_preserve_one_opaque_binding | pass | 64.334 | [native_endpoint-027.log](native_endpoint-027.log) |
| native_endpoint / result_delivery_is_required_and_cannot_be_claimed_on_a_context_request | pass | 64.628 | [native_endpoint-028.log](native_endpoint-028.log) |
| native_endpoint / session_end_invalidates_calls_and_restart_changes_binding_epoch | pass | 32.089 | [native_endpoint-029.log](native_endpoint-029.log) |
| native_endpoint / shadow_or_enabled_judge_cannot_claim_native_enforcement | pass | 3.883 | [native_endpoint-030.log](native_endpoint-030.log) |
| native_endpoint / sou12_empty_or_ambiguous_egress_never_receives_an_execution_grant | pass | 64.861 | [native_endpoint-031.log](native_endpoint-031.log) |
| native_endpoint / stages_cannot_be_replayed_or_completed_out_of_order | pass | 64.726 | [native_endpoint-032.log](native_endpoint-032.log) |
| native_endpoint / successive_parent_results_free_capacity_without_fabricating_model_context | pass | 114.905 | [native_endpoint-033.log](native_endpoint-033.log) |
| native_endpoint / typed_egress_checks_every_to_cc_and_bcc_recipient | pass | 64.562 | [native_endpoint-034.log](native_endpoint-034.log) |
| native_endpoint / typed_url_egress_does_not_accept_credentials_or_non_http_schemes | pass | 64.231 | [native_endpoint-035.log](native_endpoint-035.log) |
| native_endpoint / unknown_tools_and_changed_schema_are_not_admitted | pass | 32.411 | [native_endpoint-036.log](native_endpoint-036.log) |
| judge_endpoint / a_disabled_judge_makes_no_request_and_takes_the_fallback | pass | 64.71 | [judge_endpoint-000.log](judge_endpoint-000.log) |
| judge_endpoint / a_disabled_judge_still_honours_an_ask_fallback | pass | 64.119 | [judge_endpoint-001.log](judge_endpoint-001.log) |
| judge_endpoint / a_model_slower_than_the_timeout_falls_back_within_budget | pass | 265.083 | [judge_endpoint-002.log](judge_endpoint-002.log) |
| judge_endpoint / a_verdict_of_documentation_takes_the_allow_fallback | pass | 114.909 | [judge_endpoint-003.log](judge_endpoint-003.log) |
| judge_endpoint / a_verdict_of_injection_asks | pass | 64.473 | [judge_endpoint-004.log](judge_endpoint-004.log) |
| judge_endpoint / an_http_500_from_the_model_falls_back | pass | 64.452 | [judge_endpoint-005.log](judge_endpoint-005.log) |
| judge_endpoint / an_injection_in_the_models_answer_cannot_steer_the_daemon | pass | 64.1 | [judge_endpoint-006.log](judge_endpoint-006.log) |
| judge_endpoint / prose_instead_of_a_verdict_is_unavailable_and_falls_back | pass | 64.315 | [judge_endpoint-007.log](judge_endpoint-007.log) |

## Coverage and limits

- Existing custom-policy/local fixtures only; no agreed new ToolCallEvent integration yet.
- Judge failures use deterministic HTTP mocks, not a trained/live classifier.
- No external model calls, model weights, GPU or provider credentials.
- MCP call execution is witnessed by the fixture server ledger; result release by client stdout.
- No general OS sandbox, native macOS/Windows host acceptance or bubblewrap positive-path proof.
- Docker on macOS runs Linux containers; a container pass is not native macOS acceptance.
- Windows uses Linux Python inside WSL2; a Linux CI pass is not WSL2/Docker Desktop acceptance.
- Per-test elapsed time includes fixture startup/cleanup, not classifier or request latency.
- Accuracy, uncertainty, false-block rate and request latency require the team's labelled scenarios.

## Not measured

Classification accuracy, uncertainty, false-block rate and request latency: **not measured**. Unit-test pass counts are not classifier metrics.

## Reproduce

Run from the recorded source revision with the same platform. Dirty worktrees require the exact recorded input files as well.

```sh
python3 scripts/test-environment.py --platform linux/amd64
```

First build downloads dependencies; the test container has no external network.
