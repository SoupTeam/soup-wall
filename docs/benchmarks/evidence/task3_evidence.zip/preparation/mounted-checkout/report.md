# Local Agent/MCP fixture baseline

Status: **error**

This is the environment baseline, not completion of the shared team milestone.

## Environment

```json
{
  "host_os": "Linux",
  "host_architecture": "x86_64",
  "host_python": "3.14.4",
  "host_kernel": "6.18.33.2-microsoft-standard-WSL2",
  "wsl_detected": true,
  "wsl_distribution": "Ubuntu"
}
```

The exact image inputs, binary hashes and runtime packages are in results.json.

## Outcomes

Pass: 0; fail: 0; error: 0; skip: 0.

Infrastructure error: source-state failed; see source-state.log.

| Suite / case | Status | Fixture elapsed (ms) | Log |
| --- | --- | ---: | --- |

## Coverage and limits

- Shared adapter runner diagnostics and native/MCP fixtures are separate test surfaces.
- attack_results.json uses baseline_stub; real-classifier quality requires the separate Task 1 evaluation.
- Judge failures use deterministic HTTP mocks, not a trained/live classifier.
- No external model calls, model weights, GPU or provider credentials.
- MCP call execution is witnessed by the fixture server ledger; result release by client stdout.
- No general OS sandbox, native macOS/Windows host acceptance or bubblewrap positive-path proof.
- Docker on macOS runs Linux containers; a container pass is not native macOS acceptance.
- Windows uses Linux Python inside WSL2; a Linux CI pass is not WSL2/Docker Desktop acceptance.
- Per-test elapsed time includes fixture startup/cleanup, not classifier or request latency.
- Accuracy, uncertainty, false-block rate and request latency require the team's labelled scenarios.

## Not measured

Classification accuracy, uncertainty, false-block rate and request latency: **not measured**. Unit-test pass counts are not classifier metrics.

## Reproduce

Run from the recorded source revision with the same platform. Dirty worktrees require the exact recorded input files as well.

```sh
python3 scripts/test-environment.py --platform linux/amd64
```

First build downloads dependencies; the test container has no external network.
