# Task 3 Evidence

Current source: e4c9da71019befb46b0f3223c22a7056acea8f02. native-clean is the reported isolated latency run; native is an earlier run that overlapped a pending diagnostic and is excluded from reported distributions.

pending-admission records eight passes, one cancellation failure and two unsupported mappings. pending-isolated records nine passes and two unsupported mappings on the same source/binary. Neither establishes agreed cancellation or generic integration acceptance.

Preparation logs retain a mounted-checkout Git timeout, an incorrect local evaluator discovery path, and a pending-probe source-state refusal caused by a test-generated untracked JSON file. Corrected runs are separate. These are launcher/audit preparation errors, not fixture passes.

Historical entries are selected original artifacts at 02f1ab0/8645457, not current-source reruns. Complete earlier evidence remains in the local archive SHA-256 55810681adc9bc01cd6f5a159ffa938757c8bb80bfd7aa2e9593469c5fa781c6.

Personal checkout paths are replaced only in declared derivative copies; SANITIZATION.json records both hashes. Other retained artifacts preserve their bytes. Fixture docker-info.log is excluded. SHA256SUMS.json hashes every other entry. No credentials, compiled binaries, private datasets or model weights are included.
